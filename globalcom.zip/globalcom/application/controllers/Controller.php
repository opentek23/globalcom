<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		$this->load->library('email');
		$this->load->library('form_validation'); // Add this line

	}
	
	
	
	
	 public function accueil()
	{
		$this->load->view('Accueil');
	}



	public function apropos()
	{
		$this->load->view('Apropos');
	}
	
	public function service()
	{
		$this->load->view('Service');
	}

	
	public function contact()
	{
		$this->load->view('Contact');
	}

/* 
	public function sendEmail() {
       

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('message', 'Message', 'required');

        if ($this->form_validation->run() == FALSE) {
            // Form validation failed, display errors or handle as needed
			$this->load->view('Contact');
       
		
		} else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $message = $this->input->post('message');

            $this->email->from($email, $name);
            $this->email->to('saidmsk94@gmail.com');  // Votre adresse e-mail
            $this->email->subject('Nouveau message depuis votre site');
            $this->email->message($message);

            if ($this->email->send()) {
                // Email sent successfully
                $data['success'] = true;
				
            } else {
                // Error in sending email
                $data['error'] = true;
            }
        }

        // Charger votre vue avec les données (succès ou erreur)
        $this->load->view('Contact', $data);
    } */

	function ats() {
		$this->load->library('email');
		$this->load->helper('url');
		$this->load->helper('form');
	
		$config = array(
			'protocol' => 'smtp',
			'smtp_host' => 'smtp.gmail.com',
			'smtp_port' => '587', // Use port 587 for TLS
			'smtp_crypto' => 'tls', // Add this line for TLS
			'smtp_user' => 'saidmsk94@gmail.com',
			'smtp_pass' => 'uolj unpe rstz ycnf',
			'mailtype' => 'html',
			'charset' => 'iso-8859-1',
			'wordwrap' => 'true',
			'newline' => "\r\n"
		);
	
		$this->email->initialize($config); // Use initialize instead of load
	
		$this->email->set_newline("\r\n");
		$this->email->from("saidtriomphe@gmail.com");    
		$this->email->to("saidmsk94@gmail.com");
		$this->email->subject("Grandpopo");    
		$this->email->message("global test ");    
		if ($this->email->send()) {
			echo "Your Mail Send ";
		} else {
			echo $this->email->print_debugger();
		}
	}
// Controller.php

public function sendEmail() {
    $this->load->library('email');
    $this->load->helper('url');
    $this->load->helper('form');

    $config = array(
        'protocol' => 'smtp',
        'smtp_host' => 'smtp.gmail.com',
        'smtp_port' => '587',
        'smtp_crypto' => 'tls',
        'smtp_user' => 'saidmsk94@gmail.com',
        'smtp_pass' => 'uolj unpe rstz ycnf',
        'mailtype' => 'html',
        'charset' => 'iso-8859-1',
        'wordwrap' => 'true',
        'newline' => "\r\n"
    );

    $this->email->initialize($config);

    $name = $this->input->post('name');
    $email = $this->input->post('email');
    $message = $this->input->post('message');

    $this->email->set_newline("\r\n");
    $this->email->from($email);
    $this->email->to("saidmsk94@gmail.com");
    $this->email->subject("Contacté depuis le site web par $name");
    $this->email->message($message);

 
       
	if ($this->email->send()) {
		// Succès : Notification Flash et redirection
		$this->session->set_flashdata('success', 'Votre email a eté envoyé avec succés ');
		redirect('contact'); // Rediriger vers la page de contact
	} else {
		// Échec : Notification Flash et redirection
		$this->session->set_flashdata('error', 'Votre email  n est pas envoyé veuillez vous assurer que vous avez une connetion internet  ');
		redirect('contact'); // Rediriger vers la page de contact
	}
    
}
	
	
}