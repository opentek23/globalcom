<?php
function public_url($url=""){
  return  base_url("asset/".$url);
} ?>