<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
   <i class="scroll-top scroll-top-mobile fa fa-sort-asc"></i>
    <footer class="footer-base">
        <div class="content">
          
            <div class="row copy-row">
                <div class="col-md-12 copy-text">
                    © 2023 Globalcom - Entreprise de Technologie de l'information et de la communicaion
                </div>
            </div>
        </div>
    
    
   
    
    
        <link rel="stylesheet" href="<?php echo public_url();?>scripts/iconsmind/line-icons.min.css">
        <script async src="<?php echo public_url();?>scripts/bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo public_url();?>scripts/imagesloaded.min.js"></script>
        <script type="text/javascript" src="<?php echo public_url();?>scripts/parallax.min.js"></script>
        <script type="text/javascript" src='<?php echo public_url();?>scripts/flexslider/jquery.flexslider-min.js'></script>
        <script type="text/javascript" async src='<?php echo public_url();?>scripts/isotope.min.js'></script>
        <script type="text/javascript" src='<?php echo public_url();?>scripts/google.maps.min.js'></script>
        <script src='https://maps.googleapis.com/maps/api/js?sensor=false'></script>
        <script type="text/javascript" async src='<?php echo public_url();?>scripts/php/contact-form.js'></script>
        <script type="text/javascript" async src='<?php echo public_url();?>scripts/jquery.progress-counter.js'></script>
        <script type="text/javascript" async src='<?php echo public_url();?>scripts/jquery.tab-accordion.js'></script>
        <script type="text/javascript" async src="<?php echo public_url();?>scripts/bootstrap/js/bootstrap.popover.min.js"></script>
        <script type="text/javascript" async src="<?php echo public_url();?>scripts/jquery.magnific-popup.min.js"></script>
        <script src='<?php echo public_url();?>scripts/social.stream.min.js'></script>
        <script src='<?php echo public_url();?>scripts/smooth.scroll.min.js'></script>
       

        
    </footer>

</body>

<!-- Mirrored from templates.framework-y.com/techline/demo-main/contacts.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 02 Dec 2023 10:19:16 GMT -->
</html>
