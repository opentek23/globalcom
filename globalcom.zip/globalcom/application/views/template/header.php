<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>  

<!DOCTYPE html>
<!--[if lt IE 10]> <html  lang="en" class="iex"> <![endif]-->
<!--[if (gt IE 10)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<!-- Mirrored from templates.framework-y.com/techline/demo-main/index-services.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 02 Dec 2023 10:12:06 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Globalcom, votre partenaire à Djibouti pour la vente de matériel informatique et bureautique. Découvrez notre large gamme de produits de qualité.">
    <meta name="keywords" content="Globalcom, Djibouti, matériel informatique, bureautique, vente, services, solutions informatiques">
    <meta name="author" content="Globalcom Djibouti">
    <meta name="robots" content="index, follow">
    <meta name="og:title" content="Globalcom - Vente de Matériel Informatique et Bureautique à Djibouti">
    <meta name="og:description" content="Globalcom, votre partenaire à Djibouti pour la vente de matériel informatique et bureautique. Découvrez notre large gamme de produits de qualité.">
    <meta name="og:image" content="URL_DE_VOTRE_LOGO_OU_IMAGE">
    <meta name="og:url" content="URL_DE_VOTRE_SITE_WEB">
    <meta name="og:type" content="website">
    <title>Globalcom | Vente de Matériel Informatique et Bureautique à Djibouti</title>
    <script src="<?php echo public_url();?>scripts/jquery.min.js"></script>
    <link rel="stylesheet" href="<?php echo public_url();?>scripts/bootstrap/css/bootstrap.css">
    <script src="<?php echo public_url();?>scripts/script.js"></script>
 
    <link rel="stylesheet" href="<?php echo public_url();?>css/content-box.css">
    <link rel="stylesheet" href="<?php echo public_url();?>css/image-box.css">
    <link rel="stylesheet" href="<?php echo public_url();?>css/animations.css">
    <link rel="stylesheet" href='<?php echo public_url();?>css/components.css'>
    <link rel="stylesheet" href='<?php echo public_url();?>scripts/flexslider/flexslider.css'>
    <link rel="stylesheet" href='<?php echo public_url();?>scripts/magnific-popup.css'>
    <link rel="stylesheet" href='<?php echo public_url();?>scripts/php/contact-form.css'>
    <link rel="stylesheet" href='<?php echo public_url();?>scripts/social.stream.css'>

    <link rel="stylesheet" href="<?php echo public_url();?>style.css">

    <link rel="icon" href="<?php echo public_url();?>images/favicon.png">
    <link rel="stylesheet" href="<?php echo public_url();?>skin.css">
    <style>


/* Ajoutez ce style à votre feuille de style CSS */
.notification {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid;
}

.success {
    border-color: #4CAF50;
    background-color: #dff0d8;
    color: #4CAF50;
}

.error {
    border-color: #d9534f;
    background-color: #f2dede;
    color: #d9534f;
}

    </style>
    <!-- Extra optional content header -->
</head>
<body>
    <div id="preloader"></div>
    <header class="fixed-top scroll-change" data-menu-anima="fade-in">
        <div class="navbar navbar-default mega-menu-fullwidth navbar-fixed-top" role="navigation">
            <div class="navbar navbar-main">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="<?php echo base_url(); ?>">
                            <img class="logo-default" src="<?php echo public_url();?>images/logo.png" alt="logo" />
                            <img class="logo-retina" src="<?php echo public_url();?>images/logo-retina.png" alt="logo" />
                        </a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav">
                            <li >
                                
                            <a href="<?php echo base_url(); ?>">Accueil</a>
                             
                            </li> 
                            <li><a href="<?php echo site_url('apropos'); ?>">À propos </a></li>
                            
                            
                            <li><a href="<?php echo site_url('nos-services'); ?>">Nos Services </a></li>
                            <li><a href="<?php echo site_url('contact'); ?>">Contact </a></li>
                            <li><a href="" >Demandez-un-Devis </a></li>
                          
                        </ul>
                     
                    </div>
                </div>
            </div>
        </div>
    </header>