<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php $this->load->view('template/header');?>

    <div class="header-title ken-burn" data-parallax="scroll" data-position="top" data-natural-height="550" data-natural-width="1920" data-image-src="<?php echo public_url();?>images/bg-100.webp">
        
        <div class="container">
            <div class="title-base">
                <hr class="anima" />
                <h1>À propos</h1>
                <p>Qui-sommes-nous</p>
            </div>
            
        </div>
   
    </div>
    <div class="section-empty">
        <div class="container content">
            <div class="row">
                <div class="col-md-6">
                    <p>
                        
                        Fondée en 2011,Globalcom a été une partie intégrante de nombreuses organisation  à djibouti. 
                        Nous avons connu une croissance exponentielle au cours des  dernieres années , dans plusieurs aspects de notre entreprise. 
                        
                        <br /><br />
                        Non seulement notre précieuse equipe    a grandi, mais nous avons également continué à ajouter plusieurs produits et marques 
                        pour répondre aux besoins dynamiques et toujours changeants de nos partenaires précieux.
                       
                     
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="advs-box advs-box-side-icon box-side-icon-small" data-anima="scale-up" data-trigger="hover">
                        <div class="icon-box">
                            <i class="im-network icon anima"></i>
                        </div>
                        <div class="caption-box">
                            <h3>Équipe passionnée</h3>
                            <p>
                                Notre équipe dédiée est là pour vous offrir des solutions informatiques 
                              de la sélection de produits à l'assistance technique.                            
                            </p>
                        </div>
                    </div>
                    <hr class="space m" />
                    <div class="advs-box advs-box-side-icon box-side-icon-small" data-anima="scale-up" data-trigger="hover">
                        <div class="icon-box">
                            <i class="im-calendar-4 icon anima"></i>
                        </div>
                        <div class="caption-box">
                            <h3>Expérience professionnelle
                            </h3>
                            <p>
                                Nous nous engageons à fournir une bonne expérience client 
                                et un service satisfaisant.                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    
    <div class="section-bg-color section-item">
        <div class="container content">
            <div class="row">
              
                <!-- Materiel informatique  -->
            
                <div class="col-md-6">
                    <div class="flexslider carousel" data-options="minWidth:200,itemMargin:15,numItems:4,controlNav:true,directionNav:true">
                        <ul class="slides">
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/01.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/01.webp" alt="imprimante de marque canon">
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/02.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/02.webp" alt="imprimante epson djibouti">
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/03.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/02.webp" alt="imprimante full djibouti">
                                    </span>
                                </a>
                            </li>
                          
                        </ul>
                    </div>
                </div>

               <!-- materiels bureautique  -->
                <div class="col-md-6">
                    <div class="flexslider carousel" data-options="minWidth:200,itemMargin:15,numItems:4,controlNav:true,directionNav:true">
                        <ul class="slides">
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/04.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/04.webp" alt="materiels bureautiques ">
                                    </span>
                                </a>
                            </li>
                          
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/06.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/06.webp" alt="PC All in one djibouti">
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a class="img-box thumbnail lightbox" href="<?php echo public_url();?>images/gallery/07.webp" data-lightbox-anima="fade-left">
                                    <span>
                                        <img src="<?php echo public_url();?>images/gallery/07.webp" alt="materiels informatique djibouti">
                                    </span>
                                </a>
                            </li>
                          
                        </ul>
                    </div>
                </div>
            </div>
            <hr class="space l" />
            <p>
                Chez GlobalCom nous nous efforçons d'instaurer et de construire des relations fructueuses avec nos clients, et nous sommes fiers de proposer
                 les services et produits que nous offrons. Nous espérons continuer à être le guichet unique de nos clients pour tous leurs besoins informatiques et bureautiques.
            </p>
        </div>
    </div>



 
</div>
<i class="scroll-top scroll-top-mobile fa fa-sort-asc"></i>
<footer class="footer-base">
    <div class="content">
      
        <div class="row copy-row">
            <div class="col-md-12 copy-text">
                © 2023 Globalcom - Entreprise de Technologie de l'information et de la communicaion
            </div>
        </div>
    </div>
    <script src='<?php echo public_url();?>scripts/parallax.min.js'></script>
    <link rel="stylesheet" href="<?php echo public_url();?>scripts/iconsmind/line-icons.min.css">
    <script async src="<?php echo public_url();?>scripts/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo public_url();?>scripts/imagesloaded.min.js"></script>
    <script src='<?php echo public_url();?>scripts/jquery.twbsPagination.min.js'></script>
    <script src="<?php echo public_url();?>scripts/flexslider/jquery.flexslider-min.js"></script>
    <script src='<?php echo public_url();?>scripts/jquery.tab-accordion.js'></script>
    <script src='<?php echo public_url();?>scripts/smooth.scroll.min.js'></script>
</footer>
</body>

<!-- Mirrored from templates.framework-y.com/techline/demo-main/apropos.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 02 Dec 2023 10:18:38 GMT -->
</html>
