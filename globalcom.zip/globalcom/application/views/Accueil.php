<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  
  <?php $this->load->view('template/header');?>

  
    <div class="section-slider home-slider">
        <div class="flexslider advanced-slider slider visible-dir-nav" data-options="animation:fade">
            <ul class="slides">
                <li data-slider-anima="fade-left">
                    <div class="section-slide">
                        <div class="bg-cover" style="background-image:url('<?php echo public_url();?>images/001.webp')">
                        </div>
                        <div class="container">
                            <div class="container-middle">
                                <div class="container-inner text-left">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <h1 class="text-xl text-light anima">Fondez des partenariats robustes pour propulser le succès de votre organisation.</h1>
                                            <hr class="space xs" />
                                            <p class="anima">
                                                Découvrez l'excellence  avec nos solutions informatiques
                                                 et bureautiques de pointe. Optimisez vos performances grâce à notre gamme exceptionnelle de produits conçue pour l'excellence."
                                            </p>
                                            <hr class="space s" />
                                            <button class="btn anima anima-fade-right" type="button" onclick="window.location.href='<?php echo site_url('nos-services'); ?>'">Détails</button><span class="space"></span>
                                            <button class="btn btn-border anima anima-fade-right" type="button" onclick="window.location.href='<?php echo site_url('contact'); ?>'">Contactez-nous</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li data-slider-anima="fade-right">
                    <div class="section-slide">
                        <div class="bg-cover" style="background-image:url('<?php echo public_url();?>images/002.webp')">
                        </div>
                        <div class="container">
                            <div class="container-middle">
                                <div class="container-inner text-right">
                                    <div class="row">
                                        <div class="col-md-6 pull-right col-sm-12">
                                            <h1 class="text-xl text-light anima">2011,l'aventure est lancée
                                            </h1>
                                            <hr class="space xs" />
                                            <p class="anima">
                                                À son bord, des passionné(e)s  Tic qui accompagnent les entreprises, 
                                                administrations, commerçants, artisans, revendeurs  pour repondre efficacement aux besoins.




                                            </p>
                                            <hr class="space s" />
                                            <button class="btn anima anima-fade-right" type="button" onclick="window.location.href='services.html'">Détails</button><span class="space"></span>
<button class="btn btn-border anima anima-fade-right" type="button" onclick="window.location.href='contacts.html'">Contactez-nous</button>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
              
            </ul>
        </div>
    </div>

     <div class="section-empty section-border">
        <div class="container content">
            <div class="row">
                <div class="col-md-6">
                    <h3>À propos</h3>
                    <p  style="text-align: justify;">
                        Fondée en 2011,Globalcom a été une partie intégrante de nombreuses organisation  à djibouti. 
                        Nous avons connu une croissance exponentielle au cours des  dernieres années , dans plusieurs aspects de notre entreprise. 
                        Non seulement notre précieuse equipe    a grandi, mais nous avons également continué à ajouter plusieurs produits et marques 
                        pour répondre aux besoins dynamiques et toujours changeants de nos partenaires précieux.
                    </p>
                          
                    <a href="apropos.html" class="btn-text ">En savoir plus </a>
                    <hr>
                    <hr class="space m" />
                   

                </div>
              
                <div class="col-md-6 ">
                    <h3>INFO+</h3>
                 
                    <hr class="space xs" />
                    <ul class="list-texts">
                        <li><b>Titre:</b> Societé de technologie de l'information et de la communication</li>
                        <li><b>Branche:</b> Bureautiques , Materiels informatiques , reseaux et connectivités , Logiciels </li>
                        <li><b>Emplacement:</b>  Centre ville , en face de Igad </li>
                        <li><b>Depuis:</b>   2014</li>
                        <li><b>Horaires:</b> Samedi au jeudi  8h-16h</li>
                    </ul>
                </div>
            
            
            
            </div>
        </div>
    </div>

    <div class="section-bg-color">
        <div class="container content">
            <div class="flexslider carousel outer-navs png-over text-center" data-options="numItems:5,minWidth:100,itemMargin:30,controlNav:false,directionNav:false">
                <ul class="slides">
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/canon.webp" alt="" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/lenovo.webp" alt="" style="f-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/hp.webp" alt="" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/epson.webp" alt="" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/dell.webp" alt="" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>
                    <li>
                        <a class="img-box" href="#">
                            <img src="<?php echo public_url();?>images/logos/cisco.webp" alt=""  style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                            filter: grayscale(100%);">
                        </a>
                    </li>

                    
                </ul>
            </div>
        </div>
    </div>
  
   
	<?php $this->load->view('template/footer');?>
