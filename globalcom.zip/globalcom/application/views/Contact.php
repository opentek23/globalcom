<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php $this->load->view('template/header');?>
<div class="header-title ken-burn" data-parallax="scroll" data-position="top" data-natural-height="550"
    data-natural-width="1920" data-image-src="<?php echo public_url();?>images/bg-100.webp">




    <div class="container">
        <div class="title-base">
            <hr class="anima" />
            <h1>Contactez Nous </h1>
            <p>Restons en contact</p>
        </div>
    </div>
</div>
<div class="section-empty">
    <div class="container content">

        <div class="row">
            <div class="col-md-6">
                <h3>ENVOYER UN MESSAGE </h3>
                <p>
                    N'hésitez pas à nous contacter en complétant les champs ci-dessous. Nous nous efforçons de vous
                    assurer une réponse rapide et adaptée à vos attentes.
                </p>
                <hr class="space s" />

            
<?php if ($this->session->flashdata('success')): ?>
    <div class="notification success" id="success-notification">
        <?php echo $this->session->flashdata('success'); ?>
    </div>
<?php elseif ($this->session->flashdata('error')): ?>
    <div class="notification error" id="error-notification">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>

                <form action="<?php echo base_url('Controller/sendEmail'); ?>" method="post">
                    <div class="row">
                        <div class="col-md-6">
                            <p>Name</p>
                            <input id="name" name="name" placeholder="" type="text" class="form-control form-value"
                                required>
                        </div>
                        <div class="col-md-6">
                            <p>Email</p>
                            <input id="email" name="email" placeholder="" type="email" class="form-control form-value"
                                required>
                        </div>
                    </div>
                    <hr class="space s" />
                    <div class="row">
                        <div class="col-md-12">
                            <p>Message</p>
                            <textarea id="message" name="message" class="form-control form-value" required></textarea>
                            <hr class="space s" />
                            <button class="anima-button circle-button btn-sm btn" type="submit"><i
                                    class="im-mailbox-empty"></i>Send message</button>
                        </div>
                    </div>
                </form>

               

            </div>
            <div class="col-md-6">
                <hr class="space visible-sm" />
                <h3>NOUS JOINDRE</h3>
                <p>
                    Nous sommes là pour vous assister. Voici nos coordonnées :
                </p>
                <hr class="space s" />
                <div class="row">
                    <div class="col-md-6">
                        <ul class="fa-ul">
                            <li><i class="fa-li im-skype"></i>Globalcom Sarl</li>
                            <li><i class="fa-li im-skype"></i>P.O.Box:2019 -Djibouti</li>

                            <li><i class="fa-li im-headset"></i> (00253) 351882</li>
                            <li><i class="fa-li im-mail-3"></i> info@TechLine.com</li>
                            <li><i class="fa-li im-skype"></i> company.name</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <ul class="fa-ul">
                            <li>
                                <i class="fa-li im-home-5"></i>
                                Bd Cheickh Osman , ex Bounhour
                            </li>
                            <li>
                                <i class="fa-li im-home-5"></i>
                                Route de port à cote de Igad.
                            </li>
                        </ul>
                    </div>
                </div>
                <hr class="space m" />
                <div class="btn-group btn-group-icons" role="group">
                    <a class="btn btn-default">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="btn btn-default">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="btn btn-default">
                        <i class="fa fa-google-plus"></i>
                    </a>
                    <a class="btn btn-default">
                        <i class="fa fa-linkedin"></i>
                    </a>
                </div>
            </div>
        </div>

    </div>






</div>
<div class="section-bg-color">
    <div class="container content">
        <div class="flexslider carousel outer-navs png-over text-center"
            data-options="numItems:5,minWidth:100,itemMargin:30,controlNav:false,directionNav:false">
            <ul class="slides">
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/canon.webp" alt="canon imprimante djibouti" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/lenovo.webp" alt="lenovo djibouti" style="f-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/hp.webp" alt="hp djibouti" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/epson.webp" alt="epson djibouti" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/dell.webp" alt="dell djibouti" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>
                <li>
                    <a class="img-box" href="#">
                        <img src="<?php echo public_url();?>images/logos/cisco.webp" alt="cisco djibouti" style="-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
                                filter: grayscale(100%);">
                    </a>
                </li>


            </ul>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    // Masquer les notifications après 10 secondes
    setTimeout(function () {
        $('.notification').fadeOut();
    }, 12000); // 10000 millisecondes = 10 secondes
});
</script>

<?php $this->load->view('template/footer');?>

