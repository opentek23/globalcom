<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php $this->load->view('template/header');?>

    <div class="header-title ken-burn" data-parallax="scroll" data-position="top" data-natural-height="550" data-natural-width="1920" data-image-src="<?php echo public_url();?>images/bg-100.webp">
      
      
      
      
        <div class="container">
            <div class="title-base">
                <hr class="anima" />
                <h1>NOS SERVICES </h1>
                <p>Explorer nos differents gammes de produits</p>
            </div>
        </div>
    </div>
    <div class="section-bg-color">
        <div class="container content">
        
         

                <!-- Première paire de catégories côte à côte -->
                <div class="row">
                    <!-- Première paire de catégories côte à côte -->
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv1.webp" alt=">Ordinateurs et Portables djubouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Ordinateurs et Portables</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Ordinateurs de bureau</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Ordinateurs portables</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Workstations</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Serveurs</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <!-- Deuxième paire de catégories côte à côte -->
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv2.webp" alt="peripheriques ordinateurs djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Périphériques</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Claviers</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Souris</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Imprimantes</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Scanners</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
                <!-- Troisième paire de catégories côte à côte -->
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv3.webp" alt="Composants Informatiques djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Composants Informatiques</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Processeurs</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Cartes mères</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Cartes graphiques</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Mémoire RAM</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Disques durs</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> SSD</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <!-- Quatrième paire de catégories côte à côte -->
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv4.webp" alt="Accessoires clé usb , sacs pour le pc" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Accessoires</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 10px;"><span style="color: #007BFF;">&rarr;</span> Sacs pour ordinateurs portables</li>
                                        <li style="margin-bottom: 10px;"><span style="color: #007BFF;">&rarr;</span> Câbles</li>
                                        <li style="margin-bottom: 10px;"><span style="color: #007BFF;">&rarr;</span> Adaptateurs</li>
                                        <li style="margin-bottom: 10px;"><span style="color: #007BFF;">&rarr;</span> Chargeurs</li>
                                        <li style="margin-bottom: 10px;"><span style="color: #007BFF;">&rarr;</span> Supports pour ordinateurs</li>
                                    </ul>
                              
                                </div>
                            </div>
                        </div>
                    </div>
   
                </div>
  
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv5.webp" alt="Équipement de Bureau djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Équipement de Bureau</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Mobilier de bureau</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Lampes</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Organiseurs & Classeurs</li>
                                        <!-- Ajoutez d'autres éléments de la liste selon les catégories que vous souhaitez détailler -->
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <!-- Quatrième paire de catégories côte à côte -->
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv6.webp" alt="Logiciels informatiques djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Logiciels</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Systèmes d'exploitation</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Suites bureautiques</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Logiciels de sécurité</li>
                                        <!-- Ajoutez d'autres éléments de la liste selon les catégories que vous souhaitez détailler -->
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
   
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv7.webp" alt="Materiels reseaux et connectivités djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Réseaux et Connectivité</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Routeurs</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Commutateurs</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Câbles réseau</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Cartes réseau</li>
                                        <!-- Ajoutez d'autres éléments de la liste selon les catégories que vous souhaitez détailler -->
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <!-- Quatrième paire de catégories côte à côte -->
                    <div class="col-md-6">
                        <div class="custom-grid">
                            <div class="row">
                                <div class="col-md-4 col-12 mx-auto">
                                    <div class="img-box"><img src="<?php echo public_url();?>images/gallery/serv8.webp" alt="securité informatique djibouti" class="img-fluid rounded-circle"></div>
                                </div>
                                <div class="col-md-8 col-12">
                                    <h3>Sécurité Informatique</h3>
                                    <hr class="anima">
                                    <ul style="list-style-type: none; padding: 0; margin: 0;">
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Logiciels antivirus</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Pare-feu</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Caméras de surveillance</li>
                                        <li style="margin-bottom: 8px;"><span style="color: #007BFF;">&rarr;</span> Serrures électroniques</li>
                                        <!-- Ajoutez d'autres éléments de la liste selon les catégories que vous souhaitez détailler -->
                                    </ul>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
   
                </div>


        </div>

            
  
  
             

        </div>
    
        <?php $this->load->view('template/footer');?>
